# uber-exercicio
Esse é um exercicio proposto pela RocketSeat, recriar a interface da Uber usando React Native, foram necessárias algumas bibliotecas e uso da API do google para fazer esse exercício 

<a href="https://ibb.co/Gxkm26S"><img src="https://i.ibb.co/8K2k5CZ/collage.png" alt="collage" border="0"></a>
